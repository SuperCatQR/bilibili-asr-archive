---
plan_id: 20260923-editorial-skills
iteration: iter-2026-09-transcript-editorial-stages
iteration_compass: .mstar/iterations/iter-2026-09-transcript-editorial-stages/delivery-compass.md
iteration_refs:
  - .mstar/iterations/iter-2026-09-transcript-editorial-stages/specs/editorial-stage-contract.md
primary_spec: .mstar/iterations/iter-2026-09-transcript-editorial-stages/specs/editorial-stage-contract.md
blocked_by: []
qa_gate: mandatory
qa_mode: targeted
execution_mode: sdd
---

# 校对/精校 judgement half as two loadable agent skills + the install step

> **For agentic workers:** REQUIRED SUB-SKILL: Use `mstar-sdd`. Steps use checkbox (`- [ ]`) syntax.

**Goal:** Ship the **judgement half** of the two stages as two loadable agent skills — `SKILL.md`
packages committed in-repo as the single source of truth — plus a **verified install step** that makes
them discoverable on a host that does not auto-scan repository directories, so "AI does the work,
programs do the checking" is a repeatable pipeline stage rather than a session habit.

**Closes / advances:** plan 3 of 3 for the iteration direction (**D18**). It does not add a command and
does not change the two verifiers; it carries the half of the protocol that no command may enforce.

**Architecture:** The skills are **project products, not harness skills** (D18 non-goal): they do not join
the packaged `harness-skills/` mirror, are not linted as `mstar-*` topic skills, and are published
nowhere. They live under the product root as a small committed tree, one directory per skill, each a
`SKILL.md` with the authoring frontmatter contract (`name`, `description` as a *trigger contract*) and a
body answering the five authoring questions. The protocol content is **not re-authored**: it is the
stage contract's agent half (`§A`/`§B` "agent half", `§F`'s protocol column) restated for a reader who
has the skill loaded and has not read this iteration's package. Registration uses the host's own
skill-root mechanism (the mstar dsh plugin's `skillRoots` / a scanned root) — the task **measures** which
form works rather than assuming one, and records the measured command and its output.

**Tech Stack:** Markdown (`SKILL.md` + `references/`), the repo's existing docs tree, the host skill-root
config. No runtime dependency, no new Python.

**Execution:** mstar-sdd

**Main worktree branch**: `main` (the control root stays on `main`; feature work happens on the plan's
worktree branch created in Phase 2).

## Global Constraints

- **Two roots.** Repository root `/root/workspace/bilibili-asr-archive`; package root `<repo>/bilibili-asr-archive`. Docs live under the package root; the validation commands run from the package root.
- **No local full-suite run** — this plan changes no Python, so its evidence is document/lint checks, not a test suite.
- **The skill-authoring contract is the standard** (`mstar-skill-authoring`): frontmatter contract (`name` lowercase-hyphen, `description` a trigger contract written in the third person, **never** a workflow summary), body answering the five questions (When to load / Order and decision points / Constraints never to violate / What a correct result looks like / Which extra resources to open), progressive disclosure into `references/`.
- **The skills must not smuggle judgement into the commands, and must not restate what the commands already enforce.** Every rule id, refusal and exit code stays in the frozen CLI spec + the stage contract; the skill points at them and carries only what a command cannot check (`§F` protocol column).
- **Disclosure is mandatory**: the skill text states that it is **not loaded until installed**, and the install step is documented where an operator reads it (package `README.md` + `docs/editorial-stages.md`, shared with plan 1 Task 3).
- **Do not edit:** `{KNOWLEDGE_DIR}/**`, `{HARNESS_DIR}/workflows/**`, `status.json`, the register, other plans, the packaged `harness-skills/` mirror, and **no Python module**.
- **Corpus paths (D12)**: path-referenced, never copied into the repo. The skills must reference the corpus by its delivered path.

## Prepare gates

| Gate | State | Evidence |
|------|-------|----------|
| **specify** | done | The user's direction at lock review ("design 校对/精校 as skills, let AI do them, programs check") is recorded in `direction-lock.md` and carried as **D18**; the mechanism (host loads from configured roots; no repo auto-scan) was measured before this plan was drafted (`@mstar-harness/dsh` `dist/index.js:5186`, README § Skills mount). |
| **clarify** | done | Q1/Q6 → D11/D12; Q2/Q3/Q4 → D14/D15/D16; Q5 → contract §G. The two questions this plan raises (exact skill names; which registration form actually loads) are answered by T1 (via `naming-analyzer`) and **measured by T2**, not assumed. |
| **plan** | done (sealed 2026-09-23) | This file. |
| **primary_spec** | done | `.mstar/iterations/iter-2026-09-transcript-editorial-stages/specs/editorial-stage-contract.md` — the skills carry `§A`/`§B`'s agent half and `§F`'s protocol column. |
| **blocked_by / dependencies** | none (soft: T2's wording should follow plan 1's `docs/editorial-stages.md` if that file lands first) | The skills cite the commands' names and flagship rules; no code dependency, so the plans can land in either order inside the iteration. |

## Operator surface (product — no command is added)

This plan adds **no CLI surface**. It adds two files an agent loads and one documented install step. The
surface an operator sees:

```text
# after the install step
bili-asr align-transcripts …     # the alignment + accounting (plan 1)
bili-asr verify-proofread …      # the程序 half (plan 1)
bili-asr verify-reading-edition …# the程序 half (plan 2)
# the AI half (this plan): the two skills are listed by the host's skill catalog
```

- **Names — SETTLED by the user (2026-09-23), so T1 does not choose them:** `proofread-transcripts` and
  `polish-transcripts` (both confirmed free). The pair was resolved with the `naming-analyzer` discipline
  against the shipped family: verb-object, matching `publish-transcripts`; the two verbs state what the
  *agent does* (`proofread` / `polish`), which is exactly the half the commands do **not** do — the command
  names stay `verify-proofread` / `verify-reading-edition` because those only *check*. **Why `polish` is
  correct here although D11 rejected it as a command name:** D11 rejected it because a command that only
  verifies must not be named after the editorial act; the skill *performs* the editorial act, so on the
  skill surface the verb is accurate, not misleading. That distinction is recorded here so the two
  vocabularies are not read as a contradiction. **Retained constraint:** the host
  catalog currently serves **37** names (24 packaged `mstar-*`/`pm` + 13 user skills at `/root/.agents/skills`),
  and the candidate set was all free. The settled pair still satisfies: the two triggers must not both
  fire on the same work (the proofread skill fires on *collating two routes into a base*; the polish skill
  on *turning a base into a reading edition*), and neither may claim the `mstar-*` namespace (those are the
  packaged harness skills). If T1 finds a concrete collision at implementation time it reports it rather
  than renaming silently.
- **The install step** — the exact registration form is **measured in T2** against the host's skill-root
  mechanism; both the working form and the failure mode (committed-but-not-installed ⇒ not loaded) are
  documented. If no registration can be verified, the task reports that honestly rather than shipping a
  step that was never run.

## Tasks (sealed 2026-09-23)

### Task 1: Name + author the two skills (committed, protocol-only)

**Effort (agent-oriented):** M

**Split point:** not splittable across the two skills' *frontmatter* (both name+description pairs land first, so the
trigger contracts can be compared side by side and the two must not both fire on the same work); the two bodies may
land in separate rounds if needed — 校对 first (it is the upstream stage).

**Files:**
- Create: `bilibili-asr-archive/skills/proofread-transcripts/SKILL.md` — the proofread judgement half: reading both
  routes and adjudicating every divergence on record, the record's claim discipline, the hotword trap
  (never completing a phrase to make a sentence read), what may not be decided. Points at the stage
  contract's `§A` agent half + `§F` protocol column; carries **no** rule id and **no** exit code.
- Create: `bilibili-asr-archive/skills/polish-transcripts/SKILL.md` — the polish judgement half: the polish level
  (filler / stutter / repeat / noise), the inference rule ("only when the context forces exactly one
  reading"), the boundary statement (vocabulary unchanged, propositions not merged, register not raised;
  laughter, mood vocalisations, `哎/唉` and coarse register retained), and the `〔?〕` appendices. Points at the
  commands' rule ids by **name** (they are the checkers), never re-deciding them.
- Create (only if a skill needs variant detail): a `references/` file **inside the owning skill's own directory**
  (e.g. `bilibili-asr-archive/skills/proofread-transcripts/references/<topic>.md` — pick the topic name at authoring
  time; the wave's own examples are the likely content); keep `SKILL.md` on the main path.
- Test: no test file (documentation product) — verification is the scoped checks below.
- Out of scope: any Python module; the packaged `harness-skills/` mirror; the frozen CLI spec; the stage
  contract's own text (the skills cite it, they do not edit it).

**Interfaces:**
- Consumes (read-only, for the body's content): the stage contract's agent half (`§A`/`§B`) and protocol column
  (`§F`); `best-practices/claim-scope-discipline.md` (the record's claim discipline); `testing-patterns/hotword-list-measurement.md`
  (R1's signature the proofread skill must respect).
- Produces: two `SKILL.md` files whose frontmatter carries `name` + `description` (a trigger contract), and whose
  bodies answer the five authoring questions in the canonical section order.

**Verification (scoped-check, no fabricated tests):**
- `rg -n '^name:|^description:' bilibili-asr-archive/skills/*/SKILL.md` → both skills present, names lowercase-hyphen,
  descriptions written as triggers (third person, symptom/context shaped).
- **Run the engine's own skill lint, not a hand-rolled approximation** — `lintSkillDoc` / `lintSkillWrite` are
  exported by the installed `@mstar-harness/dsh` bundle (measured: `typeof lintSkillDoc === "function"`), i.e. the same
  validator that gates `SKILL.md` writes. Import the bundle in a throwaway node one-liner (as the PM did:
  `node --input-type=module -e "import * as m from '<bundle>/dist/index.js'; …"`), call it on both skills, and paste the
  verdict. This is the evidence that the frontmatter contract + five-question body actually hold — a regex over headings
  is only a fallback if the lint cannot be invoked, and that fallback must be reported as such.
- `rg -n '^## ' bilibili-asr-archive/skills/*/SKILL.md` → the five-question skeleton present in each (canonical titles:
  Load Order / Scope / Workflow / Decision Rules / Evidence / References).
- **Boundary check (this plan's real invariant):** `rg -n 'accounting_invalid|marker_parity|term_guard_tripped|exit 1|exit 2' bilibili-asr-archive/skills/*/SKILL.md`
  → **matches only where the skill is *pointing at* the checker** (e.g. naming the rule a command will refuse with),
  never where the skill *decides* it. Each match is quoted in the report with why it is a pointer.
- `wc -c bilibili-asr-archive/skills/*/SKILL.md` → each body is compact (progressive disclosure used for long
  examples); report the sizes.

- [ ] **Step 1:** confirm the settled names (`proofread-transcripts`, `polish-transcripts`) do not collide with the host catalog — **do not re-resolve them**; a concrete collision is reported, not renamed around · **Step 2:** author the two frontmatter trigger contracts and compare them (they must not both fire on the same work) · **Step 3:** author the 校对 body · **Step 4:** author the 精校 body · **Step 5:** run the engine's `lintSkillDoc` on both skills plus the scoped checks above, and commit (`feat(docs): the 校对/精校 judgement half as two agent skills`).

- **STOP conditions:** a skill body restates a rule the commands already enforce as if the skill decided it → STOP (D15's boundary); a skill instructs an agent to write the archive/store (any product mutation) → STOP — products come from the commands (D2); the body grows past the compactness bar and a long example is kept inline instead of moved to `references/` → STOP; a name collides with an existing host skill → STOP.

### Task 2: The install step, measured and verified

**Effort (agent-oriented):** S–M

**Split point:** not splittable — the measurement and the documented step are one deliverable; if the host's root cannot be resolved in one round, land the measurement plus an honest "not verified" report rather than a guessed path.

**Files:**
- Create: `bilibili-asr-archive/docs/editorial-skills.md` — the install/registration step for the two skills: what
  to add to the host's skill-root configuration (or the documented copy into a scanned root), the exact command,
  and how to check that the catalog now lists them. States plainly that an uninstalled skill does **not** load.
- Modify: `bilibili-asr-archive/README.md` — one pointer to that doc from the operator-facing surface (where the
  other commands are introduced), so the skills are discoverable next to the commands they pair with.
- Modify (only if the measured form is a config edit and the repo already tracks such a file): the repo's own
  host-config example, if one exists — otherwise the doc carries the snippet and nothing else changes.
- Out of scope: any change that would make skill loading depend on the repo being the launch cwd; the packaged
  mirror; `{HARNESS_DIR}` config.

**Interfaces:**
- Consumes: the two skill directories from Task 1 (the thing being installed); the host's skill-root mechanism.
  **PM-measured starting facts (verify, do not re-derive from scratch):** the mount is the `@mstar-harness/dsh`
  plugin's own — `Config` declares `skillRoots: string[]` and `bundledSkillDir: string` (`dist/index.js:5044`), and
  the provider it registers sets **`includeDefaultRoots: false`** (`:5193`), i.e. the mount serves **only** the
  configured roots plus the packaged mirror. On this machine the plugin is mounted by being an npm dependency of
  the profile (`/root/.dsh/profiles/web/package.json` → `"@mstar-harness/dsh": "^3.11.2"`) and **no `mstar` entry
  exists in `cordis.patch.yml`**, so a `skillRoots` value has no ready-made block to join — establishing *where*
  the config belongs is part of this task and its STOP conditions forbid guessing it. The repo has no `.mstarc`.
  Likely working forms, to be measured rather than assumed: (a) add a plugin entry/block carrying `skillRoots` in
  the host config, or (b) place the skills in a root the mount already serves. Whichever is measured becomes the
  documented step; if neither can be verified, the task reports that honestly.
- Produces: a documented, **executed** install step whose evidence is the command run and its output.

**Verification (scoped-check, must be an executed measurement):**
- Record the host's current skill-root configuration and the catalog state **before** the step (the two skills
  absent), run the documented step, then record the catalog state **after** (both present). The report carries the
  before/after evidence verbatim; a step that was not executed is reported as unverified, never as working.
- `rg -n 'not loaded|not installed|does not auto-scan' bilibili-asr-archive/docs/editorial-skills.md bilibili-asr-archive/skills/*/SKILL.md`
  → the disclosure exists on both surfaces.

- [ ] **Step 1:** measure the host's skill roots and the pre-state catalog · **Step 2:** determine the working registration form for this host · **Step 3:** execute it and verify the catalog lists both skills · **Step 4:** write `docs/editorial-skills.md` (+ the README pointer) with the measured command and the pre/post evidence · **Step 5:** re-run the step from a clean state if possible, then commit (`docs(skills): the verified install step for the two editorial skills`).

- **STOP conditions:** the step cannot be executed or verified on this host → STOP and report it (do not document a guessed path); the config surface cannot be established from evidence (i.e. writing `skillRoots` somewhere that the plugin never reads) → STOP — an unread key is a silent no-op, the exact failure D18 exists to prevent; the step would require editing a file outside the repo's writable surface → STOP and report; installing the skills would shadow or replace an existing skill name → STOP; the step makes the skill depend on the repo as launch cwd → STOP (the host resolves roots independently of cwd, `includeDefaultRoots: false`).

## Done criteria

1. Two `SKILL.md` packages exist under the product root, committed, each with a trigger-contract
   `description` and the five-question body (authoring contract), and neither decides what a command
   already enforces (D15's boundary, checked by the boundary rg and quoted in the report).
2. The install step is **measured and verified on this host** (pre/post catalog evidence), documented in
   `docs/editorial-skills.md` with the README pointer, including the "not loaded until installed"
   disclosure on both surfaces.
3. Compass criterion 7 holds; the skills carry no rule id, refusal or exit code as their own decision.
4. All tasks reviewed (SDD), QC + QA gate complete; residuals registered.

## Review / QA

| Field | Value |
|---|---|
| QA gate | `mandatory` / `targeted` (a documented install path that is executed, not a code change) |
| QC mode | triple (SDD) |
