---
plan_id: 20260923-reading-edition
iteration: iter-2026-09-transcript-editorial-stages
iteration_compass: .mstar/iterations/iter-2026-09-transcript-editorial-stages/delivery-compass.md
iteration_refs:
  - .mstar/iterations/iter-2026-09-transcript-editorial-stages/specs/editorial-stage-contract.md
primary_spec: .mstar/iterations/iter-2026-09-transcript-editorial-stages/specs/editorial-stage-contract.md
blocked_by: []
qa_gate: mandatory
qa_mode: targeted
execution_mode: sdd
---

# 精校 stage: reading-edition verifier + seam/concat checks

> **For agentic workers:** REQUIRED SUB-SKILL: Use `mstar-sdd`. Steps use checkbox (`- [ ]`) syntax.

**Goal:** Make the **polish stage** verifiable: an operator can run the **reading-edition verifier**
against a candidate (and, for multi-part items, its parts and their proofread base) and get a verdict
that refuses with named reasons when the candidate breaks the stage's rules — timestamps present,
characters outside the base and the two routes, **unexplained insertions**, an unclassified deletion, a
**hotword-table term deleted under cover of a "repeat"** (the `此在` blind spot), marker-parity breaks,
seam breaks, or a body that is not the byte-exact concatenation of its parts.

**Closes / advances:** plan 2 of 2 for the iteration direction.

**Architecture:** Same split as plan 1 — a **pure** rule module (`services/reading_verify.py`) and CLI
composition. The **base is the containment reference for the edition's characters only up to what the
routes support**: the 2026-09-23 close measured that a base can adjudicate a term as *correctly retained*
while the edition deletes it, and that the routes (not the base) are what proves the term was spoken
(D4 + the `此在` finding). The deletion classifier therefore takes **the base, the two routes, and the
term list**, classifies every deletion run into exactly one of three classes, and **refuses** a deletion
whose core characters belong to a term the base uses — even when it looks like an adjacent repeat.

**Tech Stack:** Python 3.12, stdlib (difflib), pytest. No new dependency.

**Execution:** mstar-sdd

**Main worktree branch**: `main`.

## Global Constraints

- Same two-roots / pinned-invocation / no-full-suite / fixtures-only constraints as plan 1 (restated there once; both plans carry the same block by reference to `{PLAN_DIR}/20260923-transcript-proofread.md` § Global Constraints).
- **The deletion classifier is the article under test.** Its known blind spot is documented and must be covered by a fixture: 「在此在」 was judged "adjacent repeat" and the term `此在` was lost; the identical shape must now **refuse**.
- **The measured false-positive episode is a constraint, not trivia**: a ±40-character window produced 50 false "content loss" hits and **0 real losses** (`README-reading-edition.md:82`); the shipped rule uses ≥ ±200 characters **and** a core-character check — the wave's recorded fix, `±200 字窗口检验`, e.g. `.tmp/proofread-work/reading/BV1vNTqzFEve.p0.p3.notes.md`. The plan's fixtures include that shape.
- **Do not edit:** `{KNOWLEDGE_DIR}/**`, `{HARNESS_DIR}/workflows/**`, `status.json`, the register, other plans. Docs limited to the files the tasks name.
- **Corpus placement (compass D12): path-referenced, never copied into the repo.** Parts + merged editions are read where they are delivered — `/mnt/123pan/bili-asr-e2e/proofread-transcripts/reading/` and `.tmp/proofread-work/{reading,reading-merged,fixed}/` (all six merged editions verified byte-identical to the delivered `reading/` tree by sha256) — with the two route sources at `/mnt/123pan/bili-asr-e2e/asr-vs-subtitle/transcripts/raw/` (ASR) and `/mnt/123pan/bili-asr-e2e/subtitle-publish/transcripts/raw/` (caption). Files are **pinned by sha256**; a missing or digest-mismatched path is a refusal naming that path, never a silent pass. Unit-level cases use crafted/synthetic fixtures only; **no transcript text is added to the repo**, so the replay is not hermetic (CI cannot run it) — accepted cost, D12.

## Prepare gates

| Gate | State | Evidence |
|------|-------|----------|
| **specify** | done | Compass `## Scope` item 2 + D4; the `此在` finding is cited in `{PROJECT_DIR}/_default/residuals.json`, and both it and the window false-positive episode are in the wave's `README-reading-edition.md` (`:104-105`, `:82`). |
| **clarify** | done | Q1 (CLI surface) and Q6 (corpus placement) **resolved by the product-manager round** into compass **D11/D12** and withdrawn from `## Open Questions`; Q2/Q3/Q4 → architect; Q5 → writing-specialist (rows carry owners in the compass). One residue was escalated rather than ruled by the chain: compass criterion 1's route-source premise went to the PM and was ruled the same day (**D13**). Compass D11 (the surface above), D12 (corpus placement), the criterion-1 marker. |
| **plan** | done (sealed 2026-09-23) | This file (+ plan 1); the four tasks are sealed with verbatim interfaces, named cases and STOP conditions. |
| **primary_spec** | done | `…/specs/editorial-stage-contract.md` §B (edition rules) + §C (shared surface). |
| **blocked_by / dependencies** | **depends on plan 1 for the contract's shared sections** | §C is shared; the two plans land in sequence inside one iteration (serial by `plan_parallelism: serial`), so no file-level block. |

## Operator surface (product — compass D11)

Fixed so no task re-opens it; the full decision, its rationale and the rejected alternatives are compass
**D11**. Everything below is the operator-facing contract of the new command.

```text
bili-asr verify-reading-edition --candidate <path> --bvid <bvid[:pN]> --base <path>
                                [--part <path>]… [--archive-root <root>]
```

- **Selector is required**: `--bvid <bvid[:pN]>` names the part whose routes the candidate is checked
  against, following the shipped `_subtitle_selector` rule (`cli.py:838-857`: bare `bvid` = every stored
  part of that video, `bvid:pN` = exactly that part). An unknown selector is the configuration error
  `verify-reading-edition: unknown --bvid <value>`, exit 1 (the shipped line form, `cli.py:1046`/`:1141`/
  `:1400`); a candidate whose frontmatter `work_id`/`bvid` disagrees with the selector is refused by name
  (the `identity_mismatch` discipline `coverage --quality` uses).
- **Accepts a single merged file or a part list + base.** `--candidate` is the edition under test (one
  merged file, or a single-part edition); `--base` is its proofread base; `--part` is repeatable and names
  the parts of a multi-part candidate. `--part` is **required exactly when the candidate declares more
  than one part** and refused by name when it contradicts the declaration — a conditional flag, not an
  accepted-but-ignored one (the README's own rule, `README.md:373-381`). Unreadable inputs are exit 1 with
  the path named, never a traceback.
- **Prints** — one line per candidate, then the closing counts line carrying every count including the
  zeros (`derive-manifest`'s shipped form):
  - `<work_id>: ok (body_chars=<n> base_chars=<n> deletions=<n> classified=<n> marks=<n> parts=<n>)` —
    `base_chars` is printed beside `body_chars` because criterion 4's recorded numbers are **ratios**
    (`body_chars`/`base_chars`, per `README-reading-edition.md`'s table);
  - `<work_id>: refused (<rule>) at <location>` — the rule named and the location (`<path>:<line>` or a
    `[hh:mm:ss]`/cue index), never a bare failure. Criterion 3's `此在` shape (「在此在」→「在」)
    refuses under the term guard; a deletion whose core is a hotword-table term the base uses is a
    refusal, not a repeat;
  - `warning (<rule>) at <location>` — an advisory: it changes neither the verdict nor the exit (the
    shipped defect-vs-advisory split, `README.md:672-679`);
  - then `verify-reading-edition: candidates=<n> ok=<n> refused=<n>`.
  - **Three line kinds are fixed; the rule vocabulary is not** — it is the architect's refusal taxonomy
    (compass Q2 → D14).
- **Exit** — `0` when every candidate is ok, **including zero candidates** (`cli.py:1098-1100`'s
  empty-is-success precedent); `1` for a usage/configuration error (an unknown `--bvid`, a missing or
  unreadable store, an unreadable `--candidate`/`--base`/`--part`, a `--part` set contradicting the
  candidate, or a required `--part` omitted) and for a candidate the command refused; **`2` is never
  produced** (no socket is opened; `_UsageErrorArgumentParser` maps argparse's own usage exit to 1).
  No new exit value — compass D8.
- **Disclosures the operator surface must carry** (criterion 5 checks them): the command verifies bytes
  and the record — it **does not polish**; no audio was listened to; both routes are machine transcripts
  and **neither is ground truth**; a `〔?〕` site is proven *marked*, never resolved.
- **Route source (compass D13)**: the ASR route from the bundle's `raw` sidecar, the caption route from
  the store (read-only) — shared with plan 1's surface; the printed lines and exit stance above are
  unaffected.
- **Rule vocabulary** — the `refused (<rule>)` / `warning (<rule>)` rule ids are the contract's `§E` table (D14); the edition rules are `timestamp_in_body`, `insertion_unexplained`, `deletion_unclassified`, `term_guard_tripped`, `twin_not_retained`, `seam_break`, `concat_mismatch`, `marker_parity`, `part_missing`.

## Tasks (sealed 2026-09-23)

### Task 1: Deletion classifier + term guard (pure)

**Effort (agent-oriented):** M

**Split point:** not splittable across the guard — the classifier may never land without it. If the round
runs short, land `deletion_runs` + `term_guard` + the 「在此在」 refusal case first (the guard is the
load-bearing half) and put the three-way classification and its cases in the round that follows; both halves
live in the same module and the same test file, so nothing is re-derived at the split.

**Files:**
- Create: `src/bili_asr/services/reading_verify.py` — pure: no sqlite, no filesystem, no I/O, no `cli` import
  (the `transcript_projection.py` precedent, `src/bili_asr/services/transcript_projection.py:92-196`).
- Test: `tests/test_reading_verify_deletions.py`.
- Out of scope: `cli.py`, `archive.py`, `storage/**`, `quality.py` (read-only precedent), the body checks
  (T2), the seam half (T3), the command composition (T4), `docs/**`.

**Interfaces:**
- Consumes: `bili_asr.quality.comparable_text` (`quality.py:466`) as the character-normalisation precedent
  for the core-character check — the module's only non-stdlib import; nothing else.
- Produces (verbatim, for T2/T3/T4):
  `DELETION_CLASSES: tuple[str, ...]` = `("filler_noise", "adjacent_repeat", "fragment")`;
  `CONTEXT_WINDOW_CHARS: int = 200`;
  `@dataclass(frozen=True) class DeletionRun:` with fields `start: int`, `deleted: str`, `context: str`,
  `retained_twin: str`, `rule: str`;
  `def deletion_runs(base_body: str, edition_body: str) -> list[DeletionRun]`
  `def term_guard(deleted: str, context: str, terms: Sequence[str]) -> str | None`
  `def classify_deletions(base_body: str, edition_body: str, routes: Mapping[str, str],
  terms: Sequence[str]) -> list[DeletionRun]`
- Honours: contract §E — `deletion_unclassified`, `term_guard_tripped`, `twin_not_retained`; the rule ids
  are §E's, and `filler_noise` / `adjacent_repeat` / `fragment` are the three classifications of a run that
  is *not* refused (D14).

**Verification:** `tests/test_reading_verify_deletions.py` — cases
`test_ci_zai_shape_refuses_under_the_term_guard` (base 「在此在」 → edition 「在」 with `此在` in the term
list: exactly one `DeletionRun` and `rule == "term_guard_tripped"` — never `adjacent_repeat`; the recorded
blind spot),
`test_adjacent_repeat_classifies_when_its_retained_twin_is_located` (「更更更高级啊，更高级」 → 「更高级啊，
更高级」: one run, `rule == "adjacent_repeat"`, `retained_twin != ""`),
`test_adjacent_repeat_without_a_retained_twin_refuses_as_twin_not_retained`,
`test_forty_char_window_false_positive_shape_is_accepted` (the measured episode,
`README-reading-edition.md:82`: 50 false hits at ±40 with 0 real losses; a run inside a ±40 context is
**accepted** under `CONTEXT_WINDOW_CHARS = 200` **plus** the core-character check, never reported as content
loss),
`test_context_of_every_reported_run_is_at_least_two_hundred_characters_each_side`,
`test_filler_noise_run_classifies_as_filler_noise`,
`test_fragment_run_classifies_as_fragment`,
`test_unclassifiable_run_refuses_as_deletion_unclassified`,
`test_a_route_span_does_not_licence_deleting_a_term_the_base_uses`.
Run: `PYTHONPATH=$PWD/src <control>/.venv/bin/python -m pytest tests/test_reading_verify_deletions.py -v`.
Before the change neither the module nor the test file exists — every case fails at collection.

**Dependency position:** wave A of this plan; T2, T3 and T4 all consume it. Serial: T1 → T2 → T3 → T4.

- [ ] **Step 1:** write the failing cases in `tests/test_reading_verify_deletions.py`; **Step 2:** run the
      selector (expect FAIL: module import error); **Step 3:** implement `DeletionRun` / `deletion_runs` /
      `term_guard` / `classify_deletions`; **Step 4:** re-run the selector (expect PASS); **Step 5:** commit
      (`feat(reading-verify): classify deletions with the hotword term guard`).
- **STOP conditions:** if any deletion whose core characters belong to a term the base uses is classified as
  `adjacent_repeat` (or as any class) instead of refusing as `term_guard_tripped`, STOP — that is the
  recorded blind spot, not a tuning choice. Equally: if `CONTEXT_WINDOW_CHARS` drops below 200 or the
  core-character check is dropped, STOP (the ±40 shape is a recorded false-positive episode, not a target);
  `quality.py:58`'s `REFERENCE_AGREEMENT_FLOOR` is never touched to make a case pass.

### Task 2: Containment, insertions, timestamps, marker parity (pure)

**Effort (agent-oriented):** S–M

**Split point:** split at the check boundary if the round runs short: (1) `Finding` + containment + the
insertion rule with their cases, then (2) timestamps + marker parity and the `verify_body` composition with
theirs. Both halves take strings and reuse T1's `DeletionRun`, so nothing is re-derived at the split — but the
containment half may not ship as an advisory: it is the refusal that carries `insertion_unexplained`.

**Files:**
- Modify: `src/bili_asr/services/reading_verify.py` — add the body checks and the shared `Finding` type;
  T1's classifier stays the only deletion authority.
- Test: `tests/test_reading_verify_body.py`.
- Out of scope: `cli.py`, `archive.py`, `storage/**`, the seam/concatenation half (T3), the command
  composition (T4), `docs/**`.

**Interfaces:**
- Consumes (verbatim from T1): `DeletionRun`; `classify_deletions(base_body: str, edition_body: str,
  routes: Mapping[str, str], terms: Sequence[str]) -> list[DeletionRun]`; `CONTEXT_WINDOW_CHARS`.
- Produces (verbatim, for T3/T4):
  `@dataclass(frozen=True) class Finding:` with fields `rule: str`, `location: str`, `detail: str`,
  `severity: str`;
  `def verify_containment(base_body: str, edition_body: str, routes: Mapping[str, str]) -> list[Finding]`
  `def verify_markers(edition_body: str, marker_rows: int | None) -> list[Finding]`
  `def verify_body(base_body: str, edition_body: str, routes: Mapping[str, str], terms: Sequence[str],
  *, marker_rows: int | None = None) -> list[Finding]`
- Honours: contract §E — `insertion_unexplained`, `timestamp_in_body`, `marker_parity`,
  `deletion_unclassified`; `severity` is `"refusal"` or `"warning"` (the defect-vs-advisory split the
  operator surface prints, `README.md:672-679`).

**Verification:** `tests/test_reading_verify_body.py` — cases
`test_single_inserted_character_refuses_as_insertion_unexplained` (the wave's per-character insert rule: one
character in the body licensed by neither the base nor either route),
`test_character_licensed_by_a_route_is_accepted`,
`test_timestamp_token_in_the_body_refuses_as_timestamp_in_body` (`[hh:mm:ss]` in the body; frontmatter is not
this rule's business),
`test_marker_count_must_equal_the_b_table_rows`,
`test_marker_count_mismatch_refuses_as_marker_parity`,
`test_marker_site_is_reported_marked_never_resolved` (a `〔?〕` site yields `severity == "warning"` — it
changes neither verdict nor exit),
`test_body_checks_return_findings_only_and_write_nothing`.
Run: `PYTHONPATH=$PWD/src <control>/.venv/bin/python -m pytest tests/test_reading_verify_body.py -v`.
Before the change `verify_body` does not exist — the cases fail at import.

**Dependency position:** wave A, serial after T1 (same module; consumes its `DeletionRun`). T3 and T4 consume
`Finding` / `verify_body`.

- [ ] **Step 1:** write the failing cases; **Step 2:** run the selector (expect FAIL: `ImportError`);
      **Step 3:** implement `Finding` / `verify_containment` / `verify_markers` / `verify_body`; **Step 4:**
      re-run the selector together with `tests/test_reading_verify_deletions.py` (both expect PASS);
      **Step 5:** commit (`feat(reading-verify): containment, insertions, timestamps, marker parity`).
- **STOP conditions:** if containment is made to pass by widening the licence beyond the base + the two
  routes (a corpus-wide character set, or an insertion admitted without a located source), STOP — an
  unexplained insertion is a refusal (D14). The marker rule compares **counts** only: if a case makes it
  resolve a `〔?〕` site instead of proving it marked, STOP.

### Task 3: Multi-part seam + concatenation verifier

**Effort (agent-oriented):** M

**Split point:** split pure from I/O: (1) `verify_concatenation` + its byte-exact cases, (2) `verify_seams`
+ its cases, then (3) the `cli.py` part-reading helper. The two pure halves share the ordered part bodies and
the helper hands them over verbatim, so nothing is re-derived at the split.

**Files:**
- Modify: `src/bili_asr/services/reading_verify.py` — add the ordered-parts aggregate and its `SeamReport`;
  T1/T2's rules unchanged.
- Modify: `src/bili_asr/cli.py` — add the part-input helper beside the multi-file reading precedent
  (`_cmd_coverage_quality`, `cli.py:1708`): resolve `--part` paths in the given order, refuse an unreadable,
  empty or duplicated part **by name**, and return the ordered bodies. It reads only — it composes nothing and
  prints nothing (that is T4).
- Test: `tests/test_reading_verify_seams.py`.
- Out of scope: `storage/**`, `archive.py`, the command's parser arm, printed lines and exit stance (T4),
  `docs/**`.

**Interfaces:**
- Consumes (verbatim from T1/T2): `classify_deletions(...)`, `verify_body(...)`, `Finding`.
- Produces (verbatim, for T4):
  `@dataclass(frozen=True) class SeamReport:` with fields `seams: list[tuple[int, int]]`,
  `findings: list[Finding]`;
  `def verify_concatenation(parts: Sequence[str], merged_body: str) -> list[Finding]`
  `def verify_seams(parts: Sequence[str]) -> SeamReport`
  `def verify_reading_edition(candidate_body: str, base_body: str, routes: Mapping[str, str],
  terms: Sequence[str], *, parts: Sequence[str] = (), marker_rows: int | None = None) -> list[Finding]`;
  in `cli.py`: `def _reading_edition_part_bodies(part_paths: Sequence[str]) -> list[str]` — unreadable input
  raises the shipped exit-1 path with the path named, never a traceback.
- Honours: contract §E — `seam_break`, `concat_mismatch`, `part_missing`; the concatenation is **byte-exact,
  one blank line between parts** (the README's own merger rule, `README.md:373-381`).

**Verification:** `tests/test_reading_verify_seams.py` — cases
`test_merged_body_not_byte_exact_against_ordered_parts_refuses_as_concat_mismatch`,
`test_concat_uses_exactly_one_blank_line_between_parts` (two blank lines refuses; zero refuses),
`test_sentence_cut_in_half_across_a_seam_refuses_as_seam_break`,
`test_clean_merger_is_accepted_and_the_seam_paragraphs_are_reported` (`findings == []` and
`len(report.seams) == len(parts) - 1`),
`test_a_single_part_edition_has_no_seam_and_is_concatenation_checked_against_itself`,
`test_part_reading_refuses_an_unreadable_part_by_name_never_a_traceback`,
`test_part_set_contradicting_the_candidate_declaration_refuses_as_part_missing`,
`test_part_reading_is_read_only` (no file under the artifact root is created or touched; the input tree's
sha256 is unchanged across the call).
Run: `PYTHONPATH=$PWD/src <control>/.venv/bin/python -m pytest tests/test_reading_verify_seams.py -v`.
Before the change neither `verify_concatenation` nor `_reading_edition_part_bodies` exists — the cases fail at
import.

**Dependency position:** wave B, serial after T2 (consumes `Finding` / `verify_body`). T4 consumes this task's
helper and aggregate; nothing else consumes it.

- [ ] **Step 1:** write the failing cases; **Step 2:** run the selector (expect FAIL: `ImportError` /
      `AttributeError`); **Step 3:** implement the pure pair and the `cli.py` helper; **Step 4:** re-run the
      selector together with the T1/T2 files (all expect PASS); **Step 5:** commit
      (`feat(reading-verify): part seam and byte-exact concatenation`).
- **STOP conditions:** if a merged body differing from the ordered parts' concatenation by even one
  character — or by one blank-line count — is accepted, STOP. And: the verifier writes nothing — if any case
  requires a file to be created, derived or cached under the artifact root, STOP (D17: the only route inputs
  are the selector `--bvid` and `--archive-root`; everything else is read from the named paths).

### Task 4: CLI (`verify-reading-edition`) + corpus replay + docs

**Effort (agent-oriented):** M

**Split point:** split the command from the corpus: (1) the parser arm + `_cmd_verify_reading_edition` + the
printed lines and exit stance, (2) the six-edition replay, (3) the docs. The replay is not hermetic (D12), so
if the path-referenced tree is absent when the round closes, land (1) + (3) with the replay case inert-and-
skipping, and land the replay itself when the tree is delivered — no rule work waits on the corpus.

**Files:**
- Modify: `src/bili_asr/cli.py` — register `verify-reading-edition` in `build_parser()` (`cli.py:96`) following
  the command-composition precedent of `_cmd_publish_transcripts` (`cli.py:1339`), on the parser class that
  already maps argparse usage errors to exit 1 (`_UsageErrorArgumentParser`, `cli.py:83`; no `2` on this path,
  D8); add `_cmd_verify_reading_edition(args)`. Flags are compass **D11** / this plan's `## Operator surface`
  verbatim: `--candidate`, `--bvid` (**required**, the `bvid[:pN]` rule of `_subtitle_selector`,
  `cli.py:838`), `--base`, repeatable `--part`, `--archive-root`. No route-source flag beyond
  `--bvid` + `--archive-root` (D17): the ASR route comes from the bundle's `raw` sidecar (`write_archive`'s
  `asr_provenance`, `archive.py:473`) and the caption route from the store read-only (D13) via
  `list_stored_transcripts` (`database.py:1205`) and `read_transcript` (`database.py:1023`).
- Modify: `{SPECS_DIR}/asr-archive-cli.md` — the command enumeration only.
- Create: `bilibili-asr-archive/docs/editorial-stages.md` (shared with plan 1 — whichever lands second extends
  it).
- Test: `tests/test_reading_verify_cli.py`.
- Out of scope: `{KNOWLEDGE_DIR}/**`, plan 1's surfaces, `services/reading_verify.py`'s rules (frozen by
  T1–T3), the register, other plans.

**Interfaces:**
- Consumes (verbatim from T3): `verify_reading_edition(...)`, `_reading_edition_part_bodies(part_paths)`.
- Produces (verbatim): `def _cmd_verify_reading_edition(args: argparse.Namespace) -> int` — returns `0` or `1`
  and never lets a traceback out of the command (the `_cmd_coverage_quality` shape, `cli.py:1708`).
- Honours: contract §C (the shared surface) + §E rule ids; the printed lines and the exit stance are compass
  D11/D8, quoted in `## Operator surface` and not re-opened here.

**Verification:** `tests/test_reading_verify_cli.py` — cases
`test_verify_reading_edition_is_registered_with_the_d11_surface` (the four flag families; `--bvid` required;
`--part` repeatable),
`test_verify_reading_edition_prints_the_candidate_line_and_the_closing_counts_line` (the six counts
`body_chars` / `base_chars` / `deletions` / `classified` / `marks` / `parts`, then
`verify-reading-edition: candidates=<n> ok=<n> refused=<n>`),
`test_verify_reading_edition_exit_is_zero_for_an_ok_candidate_and_one_for_a_refusal`,
`test_unknown_bvid_selector_exits_one_with_the_named_line`
(`verify-reading-edition: unknown --bvid <value>`),
`test_a_candidate_whose_frontmatter_contradicts_the_selector_is_refused_by_name` (the `identity_mismatch`
discipline),
`test_a_required_part_omitted_or_contradicted_is_refused_by_name_never_a_traceback`,
`test_zero_candidates_is_exit_zero` (`cli.py:1098-1100`'s empty-is-success precedent),
`test_verify_reading_edition_never_exits_two`,
`test_the_four_disclosures_are_printed` (verifies bytes and the record, does not polish; no audio was listened
to; neither route is ground truth; a `〔?〕` site is proven marked, never resolved),
`test_corpus_replay_names_a_missing_or_digest_mismatched_path_and_never_passes_silently` (skips while the
path-referenced tree is absent — a skip is not a pass, D12),
`test_gap_zero_accounting_reproduces_or_the_difference_is_named` (six merged editions; `91190 / 95022 =
0.9597`; `〔?〕` 68; local and remote copies compared by sha256).
Run: `PYTHONPATH=$PWD/src <control>/.venv/bin/python -m pytest tests/test_reading_verify_cli.py -v`.
Before the change `verify-reading-edition` is unknown to the parser — every case fails at its first
`parse_args`.

**Dependency position:** wave B, serial after T3 (consumes its aggregate and its part-reading helper).
Terminal — nothing consumes T4.

- [ ] **Step 1:** write the failing cases; **Step 2:** run the selector (expect FAIL: `SystemExit 2` from the
      unknown subcommand, i.e. the command is absent); **Step 3:** implement the parser arm and
      `_cmd_verify_reading_edition`; **Step 4:** re-run the selector together with the T1–T3 files and the
      replay (corpus present: expect PASS; corpus absent: expect the named skip), then extend
      `docs/editorial-stages.md` and the CLI enumeration; **Step 5:** commit
      (`feat(cli): verify-reading-edition`).
- **STOP conditions:** if the command returns any exit other than `0` or `1` (including argparse's own `2` on
  this path), STOP — D8. If `--bvid` becomes optional, or `--part` becomes accepted-but-ignored instead of
  required-exactly-when-the-candidate-declares-several-parts, STOP. If a missing or digest-mismatched corpus
  path yields a pass rather than a refusal naming that path, STOP (D12). And: the verifier writes nothing — if
  any step needs a mutation of the store or the artifact root, STOP (D17).

## Done criteria

1. Compass criterion 3 holds on the recorded fixtures and the six-item corpus.
2. Compass criterion 4 holds for this plan's half (numbers reproduced or differences named).
3. Compass criterion 5 holds for the new command's surfaces.
4. All tasks reviewed (SDD), QC tri + QA gate complete; residuals registered.

## Review / QA

| Field | Value |
|---|---|
| QA gate | `mandatory` / `targeted` |
| QC mode | triple (SDD) |
