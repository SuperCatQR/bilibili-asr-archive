# 单集视频

第二版正文

来源：[BVpreserve / P1](https://www.bilibili.com/video/BVpreserve/?p=1)

根据视频转录整理，经 AI 合成。

标签：源标签
