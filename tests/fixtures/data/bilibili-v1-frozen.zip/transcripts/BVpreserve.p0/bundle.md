---
bvid: "BVpreserve"
title: "保真样本"
video_title: ""
date: ""
duration_s: 3
source: "asr"
url: "https://www.bilibili.com/video/BVpreserve"
asr_vad_segments: 1
asr_vad_captured_s: 2.4
asr_vad_captured_ratio: 0.8
asr_model_name: "offline-model"
work_id: "BVpreserve:p0"
page_index: 0
cid: 2011
---

修订后的本地转录
